# arduino-project
Compilations of Arduino Projects. Properly compiled for archival and references to Arduino-related projects.

---

# Table of Contents
- [Analog Signals](https://github.com/raianah/arduino-project/tree/main/Analog%20Signals)
- [Fire Sensor Simulation](https://github.com/raianah/arduino-project/tree/main/Fire%20Sensor%20Simulation)
- [Photoresistor Simulation](https://github.com/raianah/arduino-project/tree/main/Photoresistor%20Simulation)
- [Midterms Laboratory](https://github.com/raianah/arduino-project/tree/main/Midterms%20Laboratory)
- [Light Connection using FastAPI](https://github.com/raianah/arduino-project/tree/main/Light%20Connection%20using%20FastAPI)
- [Final Laboratory](https://github.com/raianah/arduino-project/tree/main/Final%20Laboratory)
